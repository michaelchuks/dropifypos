
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>update Minimum Wallet Balance</span></h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
            <?php if(Session::get("success")): ?>
            <div class="alert alert-success">
           <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
            </div>
              <?php endif; ?>
 

    <form method="post" action="<?php echo e(url("/admin/updateminimumbalance")); ?>">
   <?php echo csrf_field(); ?>
   <label><strong>Minimum Wallet Balance</strong></label>
   <input type="number" name="balance" placeholder="N<?php echo e($minimum_balance->minimum_wallet_balance); ?>" class="form-control" required />

   <br />
   <input type="hidden" name="balance_id" value="<?php echo e($minimum_balance->id); ?>" />
   

   <input type="submit" name="update_balance_btn" value="Update" class="btn btn-sm btn-success" />


            </form>
           </div>
        </div>
    </div>



<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/settings/minimumbalance.blade.php ENDPATH**/ ?>