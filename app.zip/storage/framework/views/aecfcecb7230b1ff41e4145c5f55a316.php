
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    thead,tfoot{
        background-color:skyblue !important;
        color:black !important;
    }
    th{
        font-size:.7rem !important;
    }

    td{
        font-size:.7rem !important;
        font-weight:bold !important;
    }

    td .btn{
        font-size:.7rem !important;
    }
    </style>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h4 class="header-title" style="display:flex;align-items:center;justify-content:space-between;"><span> List of all active agents registered with <?php echo e($agreegator->name); ?></span>
            <a href="<?php echo e(url("/addagreegatoragents/$agreegator->id")); ?>" class="btn btn-success btn-sm">Assign Agents</a>
            <a href="<?php echo e(url("/agreegators")); ?>" class="btn btn-primary btn-sm">Agreegators</a>
        </h4>
           
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
               <?php endif; ?>

               <?php if(Session::get("error")): ?>
               <div class="alert alert-danger">
                <strong class="text-danger"><?php echo e(Session::get("error")); ?></strong>
               </div>
              <?php endif; ?>
               <?php if(count($users) == 0): ?>
               <strong class="text-danger">No Agent added yet</strong>
           
               <?php else: ?>

           <div class="table-responsive" id="deposits-content">
            <table  class="table table-striped dt-responsive nowrap w-100">
                <thead>
                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Pos Serial No</th>
                        <th>Wallet Balance</th>
                        <th></th>
                       
                    </tr>
                </thead>
            
            
                <tbody id="tbody">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                       <td><?php echo e($data->fullname); ?></td>
                       <td><?php echo e($data->email); ?></td>
                       <td><?php echo e($data->phone); ?></td>
                       <td><?php echo e($data->address); ?></td>
                       <td><?php echo e($data->city); ?></td>
                       <td><?php echo e($data->state); ?></td>
                       <td><?php echo e($data->pos_serial_number); ?></td>
                       <td>&#8358;<?php echo e($data->wallet); ?></td>
                       <td><a href="<?php echo e(url("user/$data->id")); ?>" class="btn btn-info btn-sm">View</a></td>
                      
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
                <tfoot>
                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Pos Serial No</th>
                        <th>Wallet Balance</th>
                       
                        <th></th>
                        
                    </tr>
                </tfoot>
            </table>
            <br />
            
            <?php echo e($users->links()); ?>

   
        
           </div>
           <?php endif; ?>
   
       </div>
      </div>
   

   


<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/agreegator/agreegator_agents.blade.php ENDPATH**/ ?>