
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span><?php echo e($activity->activity_type); ?> Deta</span>
  <button type="button" onclick="return window.history.back()" class="btn btn-sm btn-danger">Return</button>
</h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">

            <?php if(Session::get("success")): ?>
          <div class="alert alert-success">
         <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
          </div>
            <?php endif; ?>
            <?php
            if($activity->api_platform == "vtpass"){
                $details = \App\Models\VtpassTransactions::find($activity->platform_table_id);
            }else if($activity->api_platform == "transfer"){
                $details = \App\Models\Transfers::find($activity->platform_table_id);
            }else if($activity->api_platform == "withdrawal"){
                $details = \App\Models\Withdrawals::find($activity->platform_table_id);
            }
            ?>
             <div class="row">
                <div class="col-md-6">
             <h6>Transaction Details</h6>
             <p><strong>Transaction : <?php echo e($activity->activity_type); ?></strong></p>
             <p><strong>Amount : &#8358;<?php echo e($activity->amount); ?></strong></p>
             <p><strong>Status :  Successful</strong></p>
                </div>

                <div class="col-md-6">
                    <h6>Transaction Data</h6>
                    <?php if($activity->api_platform == "transfer"): ?>
                    <p><strong>Account Name : <?php echo e($details->account_name); ?></strong></p>
                    <p><strong>Account Number : <?php echo e($details->account_number); ?></strong></p>
                    <p><strong>Bank Name : <?php echo e($details->bank); ?></strong></p>
                    <p><strong>Transaction Charge : &#8358;<?php echo e($details->transaction_charge); ?></strong></p>
                    <p><strong>Reference : <?php echo e($details->reference); ?></strong></p>
                    <?php endif; ?>

                    <?php if($activity->api_platform == "withdrawal"): ?>
                    <p><strong>Card Holder : <?php echo e($details->card_holder); ?></strong></p>
                    <p><strong>Card Type : <?php echo e($details->card_scheme); ?></strong></p>
                    <p><strong>Terminal Id : <?php echo e($details->terminal_id); ?></strong></p>
                    <p><strong>Serial No : <?php echo e($details->serial_no); ?></strong></p>
                    <p><strong>Transaction Charge : &#8358;<?php echo e($details->charge); ?></strong></p>
                    <p><strong>Reference : <?php echo e($details->rrn); ?></strong></p>
                    <?php endif; ?>


                    <?php if($activity->api_platform == "vtpass"): ?>
                    <p><strong>Reciever : <?php echo e($details->unique_equivalent); ?></strong></p>
                    <p><strong>vtpass Charge : &#8358;<?php echo e($details->amount_charged); ?></strong></p>
                    <p><strong>User Charged : &#8358;<?php echo e($details->user_charge); ?></strong></p>
                    <p><strong>Reference : <?php echo e($details->transaction_id); ?></strong></p>
                    <?php endif; ?>
                    </div>
             </div>
           </div>
        </div>
    </div>



<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/activity.blade.php ENDPATH**/ ?>