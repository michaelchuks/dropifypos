
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Dropifypay Agreegators Roles
    </span> <a href="<?php echo e(route('admin.agreegator.create')); ?>" class="btn btn-sm btn-success">Update Agreegator Roles</a> </h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
               <?php endif; ?>
               <?php if(count($roles) == 0): ?>
               <strong class="text-danger">No Agreegator added yet</strong>
           
               <?php else: ?>
           <form method="post" action="<?php echo e(url("/updateagreegatorroles")); ?>">
            <?php echo csrf_field(); ?>
           <div class="table-responsive" id="deposits-content">
           <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
               <tr><th>Role</th><th>Status</th></tr>
           </thead>
           <tbody>
               <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                <td><?php echo e(ucwords($role->role)); ?></td>
               <td>
                <?php if($role->is_active == 1): ?>
                <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" checked />
                <?php else: ?>
                <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>"/>
                <?php endif; ?>
               </td>
           
               </tr>
               
               
           
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
           </table>
           <br />
           </div>
           <input type="submit" class="btn btn-sm btn-primary" value="Update" />
        </form>
           <?php endif; ?>
   
       </div>
      </div>
   

   


<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/agreegator/roles.blade.php ENDPATH**/ ?>