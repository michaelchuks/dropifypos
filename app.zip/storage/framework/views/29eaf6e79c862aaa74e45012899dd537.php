
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Update Admin</span></h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">

            <?php if(Session::get("success")): ?>
          <div class="alert alert-success">
         <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
          </div>
            <?php endif; ?>
  

    <form method="post" action="<?php echo e(url("/resetaccount")); ?>">
   <?php echo csrf_field(); ?>
  

   <br />
   <label><strong>Email</strong></label>
   <input type="text" name="email"  placeholder="<?php echo e($admin->email); ?>" class="form-control" required /><br />


   <label><strong>Password</strong></label>
   <input type="password" name="password"  class="form-control" required /><br />

   <input type="hidden" value="<?php echo e($admin->id); ?>" name="admin_id" />

   <input type="submit" name="reset_account_btn" value="Save" class="btn btn-sm btn-success" />


            </form>
           </div>
        </div>
    </div>



<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/account.blade.php ENDPATH**/ ?>