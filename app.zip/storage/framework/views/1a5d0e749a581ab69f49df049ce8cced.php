
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Withdrawals</span>     <span class="text-success">Total: <?php echo e($total); ?></h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
               <?php endif; ?>
               <?php if(count($withdrawals) == 0): ?>
               <strong class="text-danger">No Withdrawals Yet</strong>
           
               <?php else: ?>

            <input type="text" id="username" class="form-control" placeholder="Search User By Username" onkeyup="getDeposits()"/>
            <br />
            <div class="table-responsive" id="deposits-content">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr><th>Card Holder</th><th>Card Type</th><th>Amount</th><th>Transaction Charge</th><th>Reference Id</th><th>Date</th><th></th></tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $timestamp = strtotime($deposit->created_at) ;
                    $day = date("l",$timestamp);
                    $month = date("F",$timestamp);
                    $year = date("Y",$timestamp);
                    $time = date("h:i:A",$timestamp);
                    ?>
                    <tr>
                     <td><?php echo e($deposit->card_holder); ?></td>
                     <td><?php echo e($deposit->card_scheme); ?></td>
                    <td>&#8358;<?php echo e($deposit->amount); ?></td>
                    <td>&#8358;<?php echo e($deposit->charge); ?>

                    <td><?php echo e($deposit->rrn); ?></td>
                    <td><?php echo e($time); ?> <?php echo e($day); ?> <?php echo e($month); ?> <?php echo e(date("d",$timestamp)); ?> <?php echo e($year); ?></td>
         
                    <td>
                        <form method="post" action="<?php echo e(url("/deletewithdrawal")); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="withdrawal_id" value="<?php echo e($deposit->id); ?>" />
                            <button method="submit" class="btn btn-sm btn-danger" name="delete_withdrawal_btn"><span class="fa fa-trash"></span> Delete</button>
                        </form>
                    </td>
                    </tr>
                    
                    
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
                <br />
        
                <?php echo e($withdrawals->links()); ?>

                </div>
           <?php endif; ?>
   
       </div>
      </div>
   

      <script>
        function getDeposits(){
         var username = document.getElementById("username").value;
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                
                document.getElementById("deposits-content").innerHTML = this.responseText;
            }
        }
        
        xhttp.open("GET","searchdeposit?username="+username,true);
        xhttp.send();
        }
        
        </script>


<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/transactions/withdrawals.blade.php ENDPATH**/ ?>