
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.adminavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>VTPASS Airtime</span></h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
               <?php endif; ?>
               <?php if(count($vtpass_airtime) == 0): ?>
               <strong class="text-danger">No Airtime transaction yet</strong>
           
               <?php else: ?>

           
           <div class="table-responsive" id="users-content">
           <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
               <tr><th>Agent Name</th><th>Product</th><th>Performed On</th><th>Amount(N)</th><th>Amount charged(N)</th><th>User Charge(N)</th><th>Admin Share(N)</th></tr>
           </thead>
           <tbody>
               <?php $__currentLoopData = $vtpass_airtime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $charge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <td><?php echo e($charge->user->fullname); ?></td>
               <td><?php echo e($charge->product_name); ?></td>
               <td><?php echo e($charge->unique_equivalent); ?></td>
               <td><?php echo e($charge->amount); ?></td>
               <td><?php echo e($charge->amount_charged); ?></td>
               <td><?php echo e($charge->user_charge); ?></td>
               <td><?php echo e($charge->admin_share); ?></td>
               </tr>
               
               
           
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
           </table>
           <br />
   
           <?php echo e($vtpass_airtime->links()); ?>

           </div>
           <?php endif; ?>
   
       </div>
      </div>
   




<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/airtime/vtpassairtime.blade.php ENDPATH**/ ?>