
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    thead,tfoot{
        background-color:skyblue !important;
        color:black !important;
    }
    th{
        font-size:.7rem !important;
    }

    td{
        font-size:.7rem !important;
        font-weight:bold !important;
    }

    td .btn{
        font-size:.7rem !important;
    }
    </style>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h4 class="header-title" style="display:flex;align-items:center;justify-content:space-between;"><span>Active Agents Records</span>
            <a href="<?php echo e(route("admin.users.create")); ?>" class="btn btn-sm btn-success">Create Agent</a></h4>
            <p class="text-muted font-14" style="display:flex;align-items:center;justify-content:space-between;">
              <span> List of all active agents registered with dropifypay</span>
               <input type="text" id="search-term" onkeyup="search()" placeholder="Search by name,city or state" style="width:200px;" />
            </p>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
               <?php endif; ?>

               <?php if(Session::get("error")): ?>
               <div class="alert alert-danger">
                <strong class="text-danger"><?php echo e(Session::get("error")); ?></strong>
               </div>
              <?php endif; ?>
               <?php if(count($users) == 0): ?>
               <strong class="text-danger">No Agent added yet</strong>
           
               <?php else: ?>

           <div class="table-responsive" id="deposits-content">
            <table  class="table table-striped dt-responsive nowrap w-100">
                <thead>
                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Pos Serial No</th>
                        <th>Wallet Balance</th>
                        <th>Agreegator</th>
                        <th>Mapping Status</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
            
            
                <tbody id="tbody">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                       <td><?php echo e($data->fullname); ?></td>
                       <td><?php echo e($data->email); ?></td>
                       <td><?php echo e($data->phone); ?></td>
                       <td><?php echo e($data->address); ?></td>
                       <td><?php echo e($data->city); ?></td>
                       <td><?php echo e($data->state); ?></td>
                       <td><?php echo e($data->pos_serial_number); ?></td>
                       <td>&#8358;<?php echo e($data->wallet); ?></td>
                       <?php if($data->agreegator == null): ?>
                       <td>No Agreegator</td>
                       <?php else: ?>
                       <td><?php echo e($data->agreegator->name); ?></td>
                       <?php endif; ?>
                       <td>
                        <?php if($data->Mapping_status == "unmapped"): ?>
                        <span class="text-danger">Unmapped</span>
                        <?php else: ?>
                        <span class="text-success">Mapped</span>
                        <?php endif; ?>
                       </td>
                       <td><a href="<?php echo e(url("user/$data->id")); ?>" class="btn btn-info btn-sm">View</a></td>
                        <td><a href="<?php echo e(url("agentwallet/$data->id")); ?>" class="btn btn-sm btn-success">Manage Wallet</a></td>
                       <td>
                        <?php if($data->Mapping_status == "unmapped"): ?>
                        <a href="<?php echo e(url("/mapagent/$data->id")); ?>" type="button" class="btn btn-sm btn-success">Map Agent</a>
                        <?php else: ?>
                         <form method="post" action="<?php echo e(url("/unmapagent")); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="agent_id" value="<?php echo e($data->id); ?>"/> 
                           <input type="submit" name="unmap_agent_btn" value="Unmap Agent" class='btn btn-sm btn-secondary' onclick="return confirm('are you sure you want to unmap agent')" />
                         </form>
                        <?php endif; ?>
                        <td>
                            <?php if($data->agreegator == null): ?>
                            <td><a href="<?php echo e(url("/addagreegator/$data->id")); ?>" class="btn btn-sm btn-primary">Add Agreegator</a</td>
                            <?php else: ?>
                            <td>
                                <form method="post" action="<?php echo e(url("/removeagreegator")); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="agent_id" value="<?php echo e($data->id); ?>" />
                                    <input type="submit" class="btn btn-sm btn-normal" style="background-color:purple;color:white" onclick="return confirm('are you sure you want to remove agent agreegator')" value="Remove Agreegator" />
                                </form>
                            </td>
                            <?php endif; ?>
                       <td>
                        <form method="post" action="<?php echo e(url("/suspendagent")); ?>">
                            <?php echo csrf_field(); ?>
                         <input type="hidden" name="agent_id" value="<?php echo e($data->id); ?>"  />
                         <input type="submit" name="suspend_user_btn" class="btn btn-sm btn-danger" onclick="return confirm('are you sure you want to suspend agent')" value="Suspend Agent" />
                        </form></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
                <tfoot>
                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Pos Serial No</th>
                        <th>Wallet Balance</th>
                        <th>Agreegator</th>
                        <th>Mapping Status</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
            <br />
            
            <?php echo e($users->links()); ?>

   
        
           </div>
           <?php endif; ?>
   
       </div>
      </div>
   

   


<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    function search(){
        var tbody = document.getElementById("tbody");
        var searchTerm = document.getElementById("search-term").value;
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
               tbody.innerHTML = this.responseText;
            }
        }

        xhttp.open("GET","searchuser?term="+searchTerm,true);
        xhttp.send();
    }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/users/index.blade.php ENDPATH**/ ?>