
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Dropifypay Subadmins
    </span> <a href="<?php echo e(route('admin.subadmin.create')); ?>" class="btn btn-sm btn-success">Create Subadmin</a> </h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
               <?php endif; ?>
               <?php if(count($subadmins) == 0): ?>
               <strong class="text-danger">No Subadmin added yet</strong>
           
               <?php else: ?>

           <div class="table-responsive" id="deposits-content">
           <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
               <tr><th>Fullname</th><th>Email</th><th>Image</th><th></th><th></th></tr>
           </thead>
           <tbody>
               <?php $__currentLoopData = $subadmins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr><td><?php echo e(ucwords($deposit->name)); ?></td>
               <td><?php echo e($deposit->email); ?></td>
               <td><img src="<?php echo e(asset("storage/subadmin/$deposit->image")); ?>" style="width:200px;height:180px;" /></td>
               <td><?php echo e($deposit->created_at); ?></td>
    
               <td>
               
            <a href="<?php echo e(url("/deletesubadmin/$deposit->id")); ?>" class="btn btn-sm btn-danger"><span class="fa fa-trash"></span> Delete</a>
                   
               </td>
               </tr>
               
               
           
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
           </table>
           <br />
   
        
           </div>
           <?php endif; ?>
   
       </div>
      </div>
   

   


<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dropifyp/dropifypos/resources/views/subadmin/index.blade.php ENDPATH**/ ?>