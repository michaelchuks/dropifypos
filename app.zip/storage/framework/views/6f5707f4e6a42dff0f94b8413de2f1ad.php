
<form method="post" action="<?php echo e(url("/initiateflutterwavetransfer")); ?>">
    <?php echo csrf_field(); ?>
<label>Select Bank</label>
<select name="bank_code">
    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($bank->code); ?>"><?php echo e($bank->bank); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<br />

<label>Account Number</label>
<input type="phone" name="account_number" required />
<br />


<label>Amount</label>
<input type="number" name="amount" required />
<br />


<label>Naration</label>
<input type="text" name="narration" />

<br />

<input type="submit" value="Continue" />
</form><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/transfers/flutterwave/index.blade.php ENDPATH**/ ?>