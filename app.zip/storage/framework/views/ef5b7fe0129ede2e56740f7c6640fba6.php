
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .form-layout{
        display:flex !important;
        align-items:center !important;
        justify-content: space-between !important;
    }

    .form-layout .layout-content{
        display:grid !important;
    }
    </style>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Dropifypay Pos Activities for <?php echo e($data); ?></span> <span class="text-success">Total: <?php echo e($total); ?></span>
   <?php if($type == "day" && count($activities) > 0): ?>
    <a  href="<?php echo e(url("/dayanalytics")); ?>" class="btn btn-sm btn-primary">View Analytic</a>
   <?php endif; ?>

   <?php if($type == "week" && count($activities) > 0): ?>
   <a  href="<?php echo e(url("/weekanalytics")); ?>" class="btn btn-sm btn-primary">View Analytic</a>
  <?php endif; ?>


  <?php if($type == "month" && count($activities) > 0): ?>
  <a  href="<?php echo e(url("/monthanalytics")); ?>" class="btn btn-sm btn-primary">View Analytic</a>
 <?php endif; ?>
</h6>
    <?php if($data == "all"): ?>
   <?php
      $admin = \App\Models\Admin::first();
        $timestamp = strtotime($admin->created_at);
        $end_year = date("Y");
        $start_year = date("Y");
        $years_array = array();
        for($year = $start_year; $year >= $end_year;$year--){
            array_push($years_array,$year);
        }
        $day_array = ["01","02","03","04","05","06","07","08","09","10","11","12","13",'14','14','16',
        "17","18",'19','20','21','22','23','24','25','26','27','28','29','30','31'
    ];

        $month_array = ["January","February","March","April","May","June","July","August","September",
        "October","November","December"];
    ?>
    <?php endif; ?>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
               <?php endif; ?>
               <?php if(count($activities) == 0): ?>
               <strong class="text-danger">No Activities yet</strong>
         <?php else: ?>
         <?php if($data == "all"): ?>
         <form method="post">
            <?php echo csrf_field(); ?>
         <div class="form-layout">
            <div class="layout-content">
             <label>Year</label>
             <select name="year">
             <option value="all">All</option>
             <?php $__currentLoopData = $years_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
            </div>

              <div class="layout-content">
                <label>Month</label>
                <select name="month">
                <option value="all">All</option>
                <?php $__currentLoopData = $month_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($month); ?>"><?php echo e($month); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
               </div>


               <div class="layout-content">
                <label>Day</label>
                <select name="day">
                <option value="all">All</option>
                <?php $__currentLoopData = $day_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($day); ?>"><?php echo e($day); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
               </div>

               <div class="layout-content">
                 <input type="submit" class="btn btn-sm btn-success" value="Search Data" />
               </div>

         </div>

         </form>
         <br />
         <?php endif; ?>
           <div class="table-responsive" id="deposits-content">
           <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
               <tr><th>Agent Name</th><th>Transaction Type</th><th>Amount</th><th>Date And Time</th><th></th></tr>
           </thead>
           <tbody>
               <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php
               $timestamp = strtotime($data->created_at) ;
               $day = date("l",$timestamp);
               $month = date("F",$timestamp);
               $year = date("Y",$timestamp);
               $time = date("h:i:A",$timestamp);
               ?>
               <tr><td><?php echo e(ucwords($data->user->fullname)); ?></td>
                <td><?php echo e($data->activity_type); ?></td>
               <td>&#8358;<?php echo e($data->amount); ?></td>
               <td><?php echo e($time); ?> <?php echo e($day); ?> <?php echo e($month); ?> <?php echo e(date("d",$timestamp)); ?> <?php echo e($year); ?></td>
               <td><a href="<?php echo e(url("/activity/$data->id")); ?>" class="btn btn-sm btn-success">View Details</a>
               </tr>
               
               
           
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
           </table>
           <br />
   
           <?php echo e($activities->links()); ?>

           </div>
           <?php endif; ?>
   
       </div>
      </div>
   

      <script>
        function getActivities(){
         var username = document.getElementById("username").value;
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                
                document.getElementById("deposits-content").innerHTML = this.responseText;
            }
        }
        
        xhttp.open("GET","searchactivity?username="+username,true);
        xhttp.send();
        }
        
        </script>


<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/activities.blade.php ENDPATH**/ ?>