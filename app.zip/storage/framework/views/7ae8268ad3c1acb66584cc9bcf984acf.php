
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.adminavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Transaction Commisions</span> <a href="<?php echo e(url("/newcommission")); ?>" class="btn btn-sm btn-success"><span class="fa fa-plus"></span>Add Commission</a></h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
               <?php endif; ?>
               <?php if(count($transaction_charges) == 0): ?>
               <strong class="text-danger">No Commission set</strong>
           
               <?php else: ?>

           
           <div class="table-responsive" id="users-content">
           <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
               <tr><th>Transaction</th><th>Api Platform</th><th>Agent Commission(%)</th><th></th></tr>
           </thead>
           <tbody>
               <?php $__currentLoopData = $transaction_charges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $charge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <td><?php echo e($charge->transaction_type); ?></td>
               <td><?php echo e($charge->charge); ?>%</td>
               <td><a href="<?php echo e(url("/commission/$charge->id")); ?>" class="btn btn-sm btn-success"><span class="fa fa-compass"></span> Edit</a></td>
               <td>
                   <form method="post" action="<?php echo e(url("/deletecommission")); ?>">
                       <?php echo csrf_field(); ?>
                       <input type="hidden" name="charge_id" value="<?php echo e($charge->id); ?>" />
                       <button method="submit" class="btn btn-sm btn-danger" name="delete_charge_btn"><span class="fa fa-trash"></span> Delete</button>
                   </form>
               </td>

               </tr>
               
               
           
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
           </table>
           <br />
   
           <?php echo e($transaction_charges->links()); ?>

           </div>
           <?php endif; ?>
   
       </div>
      </div>
   




<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dropifyp/dropifypos/resources/views/settings/charges.blade.php ENDPATH**/ ?>