
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    thead,tfoot{
        background-color:skyblue !important;
        color:black !important;
    }
    th{
        font-size:.7rem !important;
    }

    td{
        font-size:.7rem !important;
        font-weight:bold !important;
    }

    td .btn{
        font-size:.7rem !important;
    }
    </style>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Dropifypay Agreegators Share Percentage
    </span>  </h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
               <?php endif; ?>
             

           <div class="table-responsive" id="deposits-content">
           <table class="table table-striped dt-responsive nowrap w-100">
           <thead>
               <tr><th>Transaction Type</th><th>Agreegator Share</th><th></th></tr>
           </thead>
           <tbody>
               <?php $__currentLoopData = $transaction_shares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
               <tr><td><?php echo e(ucwords($deposit->transaction_type)); ?></td>
               <td><?php echo e($deposit->agreegator_percentage); ?>%</td>
               
                <td>
                    <form method="post" action="<?php echo e(url("/updateagreegatortransactionshare")); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="share_percentage_id" value="<?php echo e($deposit->id); ?>" />
                         <input type="number" step='any' placeholder="<?php echo e($deposit->agreegator_percentage); ?>%" name="agreegator_percentage" class="form-control" />
                          <br />
                         <input type="submit" name="delete_agreegator_btn" class="btn btn-sm btn-success" value="Update" />
                       
                    </form>
                   
               </td>
               </tr>
               
               
           
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
           </table>
           <br />
   
        
           </div>
      
   
       </div>
      </div>
   

   


<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/agreegator/share_percentage.blade.php ENDPATH**/ ?>