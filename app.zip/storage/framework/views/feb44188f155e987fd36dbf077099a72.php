
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                  
                                </div>
                                <h4 class="page-title">Update Agent Details</h4>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title" style="display:flex;align-items:center;justify-content:space-between;"><span>New Agent</span> <a href="<?php echo e(url("/user/$user->id")); ?>" class="btn btn-sm btn-success">Back to profile</a></h4>
                                    <p class="text-muted font-14">
                                      Update Agent Details Below
                                    </p>

                                  


                    <!-- Form row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Agent Details</h4>
                                    <p class="text-muted font-14">
                                      Correct agent details are neccessary
                                    </p>

                                      <?php if(Session::get("success")): ?>
                                      <div class="alert alert-success">
                                        <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                                      </div>
                                      <?php endif; ?>
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="form-row-preview">
                                            <form  method="post" action="<?php echo e(route("admin.users.update")); ?>" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="row g-2">
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputEmail4" class="form-label">Name</label>
                                                        <input type="text" value="<?php echo e($user->fullname); ?>" name="fullname" class="form-control" id="inputEmail4" placeholder="Full Name" >
                                                    </div>
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputPassword4" class="form-label">Email</label>
                                                        <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><strong class="text-danger"><?php echo e($message); ?></strong></small><br /><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <input type="email" value="<?php echo e($user->email); ?>" class="form-control" name="email" id="inputPassword4" placeholder="Email" >
                                                    </div>
                                                </div>


                                                <div class="row g-2">
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputEmail4" class="form-label">Phone</label>
                                                        <?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><strong class="text-danger"><?php echo e($message); ?></strong></small><br /><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <input type="tel" name="phone" value="<?php echo e($user->phone); ?>" class="form-control" id="inputEmail4" placeholder="Phone No" >
                                                    </div>
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputPassword4" class="form-label">State</label>
                                                        <select name="state" class="form-control">
                                                            <option value="<?php echo e($user->state); ?>"><?php echo e($user->state); ?></option>
                                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($state->state != $user->state): ?>
                                                             <option value="<?php echo e($state->state); ?>"><?php echo e($state->state); ?></option>
                                                             <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>



                                                <div class="row g-2">
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputEmail4" class="form-label">City</label>
                                                        <input type="text" value="<?php echo e($user->city); ?>" name="city" class="form-control" id="inputEmail4" placeholder="City" >
                                                    </div>
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputPassword4" class="form-label">Address</label>
                                                        <input type="text" value="<?php echo e($user->city); ?>" name="address" class="form-control"  placeholder="Address"  />
                                                    </div>
                                                </div>

                                               
                                                <div class="row g-2">
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputEmail4" class="form-label">BVN</label>
                                                        <input type="text" name="BVN" value="<?php echo e($user->BVN); ?>" class="form-control" id="inputEmail4" placeholder="Bank Verification Number" >
                                                    </div>
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputPassword4" class="form-label">NIN</label>
                                                        <input type="NIN" name="NIN" value="<?php echo e($user->NIN); ?>" class="form-control"  placeholder="NIN"  />
                                                    </div>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="inputAddress" class="form-label">Passport Photograph <small><strong>(a png,jpg,jpeg image not more than 3mb)</strong></small></label>
                                                    <?php $__errorArgs = ["profile_image"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><strong class="text-danger"><?php echo e($message); ?></strong></small><br /><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    <input type="file" name="profile_image"  class="form-control" id="inputAddress" placeholder="Profile Image" >
                                                </div>

                                              
                                                 <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>" />
                                              

                                                <button type="submit" name="update_user_btn" class="btn btn-primary">Update Agent</button>
                                            </form>
                                        </div> <!-- end preview-->

                                     
                                    </div> <!-- end tab-content-->



                                    <br />

                                    <h6><strong> Update Business Details</strong></h6>

                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="form-row-preview">
                                            <form  method="post" action="<?php echo e(route("admin.users.updatebusinessdetails")); ?>" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="mb-3">
                                                    <label for="inputAddress2" class="form-label">Business Name</label>
                                                    <input type="text" value="<?php echo e($business_details->business_name); ?>" class="form-control" id="inputPassword4" placeholder="Business Name" name="business_name" >
                                                </div>


                                                <div class="mb-3">
                                                    <label for="inputAddress" class="form-label">CAC Certificate <small><strong>(a png,jpg,jpeg image not more than 3mb)</strong></small></label>
                                                    <?php $__errorArgs = ["CAC_certificate"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><strong class="text-danger"><?php echo e($message); ?></strong></small><br /><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    <input type="file" name="CAC_certificate" class="form-control" id="inputAddress" placeholder="CAC" >
                                                </div>

                                                    <input type="hidden"  name="user_id" value="<?php echo e($user_id); ?>" />
                                                <div class="mb-3">
                                                    <label for="inputAddress2" class="form-label">RC Number(optional)</label>
                                                    <input type="text" value="<?php echo e($business_details->RC_number); ?>" class="form-control" id="inputPassword4" placeholder="RC Number" name="RC_number" >
                                                </div>
                                                  <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>" />
                                                <button type="submit" name="update_business_btn" class="btn btn-primary">Update</button>
                                            </form>
                                        </div> <!-- end preview-->
                                    </div>








                                </div> <!-- end card-body -->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- container -->

            </div> <!-- content -->



<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dropifyp/dropifypos/resources/views/users/edit.blade.php ENDPATH**/ ?>