
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Create Subadmin</span></h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">

            <?php if(Session::get("success")): ?>
          <div class="alert alert-success">
         <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
          </div>
            <?php endif; ?>
  

    <form method="post" action="<?php echo e(route("admin.subadmin.store")); ?>" enctype="multipart/form-data">
   <?php echo csrf_field(); ?>
  

   <br />
   <label><strong>Name</strong></label>
   <input type="text" name="name"  placeholder="Subadmin Name" class="form-control" required /><br />




   <label><strong>Email</strong></label>
   <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><br /><small class="text-danger"><strong><?php echo e($message); ?></strong></small><br /><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   <input type="text" name="email"  placeholder="Subadmin email" class="form-control" required /><br />


   <label><strong>Image</strong></label>
   <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><br /><small class="text-danger"><strong><?php echo e($message); ?></strong></small><br /><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   <input type="file" name="image"  placeholder="image" class="form-control" required /><br />


   <label><strong>Password</strong></label>
   <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><br /><small class="text-danger"><strong><?php echo e($message); ?></strong></small><br /><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   <input type="password" name="password"  class="form-control" required /><br />



   <input type="submit" name="reset_account_btn" value="Save" class="btn btn-sm btn-success" />


            </form>
           </div>
        </div>
    </div>



<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/subadmin/create.blade.php ENDPATH**/ ?>