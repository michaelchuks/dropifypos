
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Admin vtpass Wallet Balance</span></h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
         
 
<center>

<h4><strong>Your vtpass wallet balance</strong></h4>
<h2><strong><del>N</del><?php echo e($wallet_balance); ?></strong></h2>
</center>
           </div>
        </div>
    </div>



<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/settings/vtpassbalance.blade.php ENDPATH**/ ?>