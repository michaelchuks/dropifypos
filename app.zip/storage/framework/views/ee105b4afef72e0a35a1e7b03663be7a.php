<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($data->fullname); ?></td>
<td><?php echo e($data->email); ?></td>
<td><?php echo e($data->phone); ?></td>
<td><?php echo e($data->address); ?></td>
<td><?php echo e($data->city); ?></td>
<td><?php echo e($data->state); ?></td>
<td><a href="<?php echo e(url("user/$data->id")); ?>" class="btn btn-info btn-sm">View</a></td>
<td>
 <form method="post" action="<?php echo e(url("/suspenduser")); ?>">
     <?php echo csrf_field(); ?>
  <input type="hidden" name="user_id" value="<?php echo e($data->id); ?>"  />
  <input type="submit" name="suspend_user_btn" class="btn btn-sm btn-danger" onclick="return confirm('are you sure you want to suspend agent')" value="Suspend Agent" />
 </form></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/dropifyp/dropifypos/resources/views/users/namesearch.blade.php ENDPATH**/ ?>