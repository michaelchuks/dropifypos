
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                 
                                </div>
                                <h4 class="page-title"><span>Regsitered Agents</span></h4>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title" style="display:flex;align-items:center;justify-content:space-between;"><span>Unactivated Agents Records</span>  <a href="<?php echo e(route("admin.users.create")); ?>" class="btn btn-sm btn-success">Create Agent</a></h4>
                                     
                                    <p class="text-muted font-14" style="display:flex;align-items:center;justify-content:space-between;">
                                      <span> List of all unactivated agents registered with dropifypay</span>
                                       <input type="text" id="search-term" onkeyup="search()" placeholder="Search by name,city or state" style="width:200px;" />
                                      
                                      
                                    </p>
                                     <?php if(Session::get("success")): ?>
                                     <div class="alert alert-success">
                                      <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                                     </div>
                                     <?php endif; ?>
                                   
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="basic-datatable-preview">
                                            <table  class="table table-striped dt-responsive nowrap w-100">
                                                <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>Address</th>
                                                        <th>City</th>
                                                        <th>State</th>
                                                        <th></th>
                                                        <th></th>
                                                    </tr>
                                                </thead>


                                                <tbody id="tbody">
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?>

                                                       <td><?php echo e($data->fullname); ?></td>
                                                       <td><?php echo e($data->email); ?></td>
                                                       <td><?php echo e($data->phone); ?></td>
                                                       <td><?php echo e($data->address); ?></td>
                                                       <td><?php echo e($data->city); ?></td>
                                                       <td><?php echo e($data->state); ?></td>
                                                       <td><a href="<?php echo e(url("user/$data->id")); ?>" class="btn btn-info btn-sm">View</a></td>
                                                       <td>
                                                        <form method="post" action="<?php echo e(url("/activateuser")); ?>">
                                                            <?php echo csrf_field(); ?>
                                                         <input type="hidden" name="user_id" value="<?php echo e($data->id); ?>"  />
                                                         <input type="submit" name="activate_user_btn" class="btn btn-sm btn-success" onclick="return confirm('are you sure you want to activate agent')" value="Activate Agent" />
                                                        </form></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th></th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>Address</th>
                                                        <th>City</th>
                                                        <th>State</th>
                                                        <th></th>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                            <br />

                                          
                                        </div> <!-- end preview-->

                                       
                                    </div> <!-- end tab-content-->
                                </div> <!-- end card body-->
                            </div> <!-- end card -->
                        </div><!-- end col-->
                    </div> <!-- end row-->
                </div> <!-- container -->

            </div> <!-- content -->


            <script>
                function search(){
                    var tbody = document.getElementById("tbody");
                    var searchTerm = document.getElementById("search-term").value;
                    var xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function(){
                        if(this.readyState == 4 && this.status == 200){
                           tbody.innerHTML = this.responseText;
                        }
                    }

                    xhttp.open("GET","searchuser?term="+searchTerm,true);
                    xhttp.send();
                }

                </script>

<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



















<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/users/unactivated_users.blade.php ENDPATH**/ ?>