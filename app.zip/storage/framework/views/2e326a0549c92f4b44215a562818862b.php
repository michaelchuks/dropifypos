
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                  
                                </div>
                                <h4 class="page-title">Add Agent Pos Serial Number</h4>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                   
                                    <p class="text-muted font-14">
                                       Enter New Agent Pos Serial Number Below
                                    </p>

                                  


                    <!-- Form row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Agent Serial</h4>
                                    <p class="text-muted font-14">
                                      Correct agent Pos Serial Number details are neccessary
                                    </p>

                                      <?php if(Session::get("success")): ?>
                                      <div class="alert alert-success">
                                        <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                                      </div>
                                      <?php endif; ?>
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="form-row-preview">
                                            <form  method="post" action="<?php echo e(url("/activateuser")); ?>" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="row g-2">
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputEmail4" class="form-label">Name</label>
                                                        <input type="text" value="<?php echo e(old("fullname")); ?>" name="fullname" class="form-control" id="inputEmail4" placeholder="<?php echo e($user->fullname); ?>" readonly>
                                                    </div>
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputPassword4" class="form-label">Pos Serial Number</label>
                                                        <?php $__errorArgs = ["pos_serial_number"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><strong class="text-danger"><?php echo e($message); ?></strong></small><br /><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <input type="text" value="<?php echo e(old("serial_number")); ?>" class="form-control" name="pos_serial_number" id="inputPassword4" placeholder="Pos Serial Number" required>
                                                    </div>
                                                </div>
                                                
                                                <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>" />

                                                <button onclick="return confirm('are you sure you want to activate agent')" type="submit" name="activate_user_btn" class="btn btn-primary">Activate Agent</button>
                                            </form>
                                        </div> <!-- end preview-->

                                     
                                    </div> <!-- end tab-content-->

                                </div> <!-- end card-body -->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- container -->

            </div> <!-- content -->



<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dropifyp/dropifypos/resources/views/users/serial_number.blade.php ENDPATH**/ ?>