
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                  
                                </div>
                                <h4 class="page-title">Assign Agents <?php echo e($agreegator->name); ?> <a href="<?php echo e(url("agreegatoragents/$agreegator->id")); ?>" class="btn btn-sm btn-danger">Return</a></h4>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                   
                                    <p class="text-muted font-14">
                                      Assign Agents Below by checking the boxes
                                    </p>

                                  


                    <!-- Form row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title"></h4>
                                   

                                      <?php if(Session::get("success")): ?>
                                      <div class="alert alert-success">
                                        <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                                      </div>
                                      <?php endif; ?>

                                      <?php if(Session::get("error")): ?>
                                      <div class="alert alert-danger">
                                        <strong class="text-danger"><?php echo e(Session::get("error")); ?></strong>
                                      </div>
                                      <?php endif; ?>
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="form-row-preview">
                                            <form  method="post" action="<?php echo e(url("/assignagreegatoragents")); ?>">
                                                <?php echo csrf_field(); ?>
                                                 <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <p><strong><?php echo e($user->fullname); ?> - <?php echo e($user->city); ?> ,<?php echo e($user->state); ?> state</strong> <input type="checkbox" name="agents[]" value="<?php echo e($user->id); ?>" /></p>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <input type="hidden" name="agreegator_id" value="<?php echo e($agreegator->id); ?>" />

                                                <button  type="submit" name="wallet_Agreegator_btn" class="btn btn-primary">Assign Agents</button>
                                            </form>
                                        </div> <!-- end preview-->

                                     
                                    </div> <!-- end tab-content-->

                                </div> <!-- end card-body -->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- container -->

            </div> <!-- content -->



<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/agreegator/add_agents.blade.php ENDPATH**/ ?>