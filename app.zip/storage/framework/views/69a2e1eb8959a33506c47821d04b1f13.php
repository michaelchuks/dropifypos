
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>update Commission</span></h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
   <p>Api Platform : <?php echo e($charge->api_platform); ?></p>
   <p>Transaction Type : <?php echo e($charge->transaction_type); ?></p>

    <form method="post" action="<?php echo e(url("/updatecommission")); ?>">
   <?php echo csrf_field(); ?>
   <label><strong class="text-success">Commission(%)</strong></label>
   <input type="number" name="charge" placeholder="<?php echo e($charge->charge); ?>%" class="form-control"  />
  <br />
   <label><strong>Select Package Type</strong></label>
   <select name="package_type" class="form-control">
    <option value="<?php echo e($charge->package_type); ?>"><?php echo e(ucwords($charge->package_type)); ?></option>  
   </select>
   <br />

   <br />
   <input type="hidden" name="charge_id" value="<?php echo e($charge->id); ?>" />
   

   <input type="submit" name="update_charge_btn" value="Update" class="btn btn-sm btn-success" />


            </form>
           </div>
        </div>
    </div>



<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dropifyp/dropifypos/resources/views/settings/charge.blade.php ENDPATH**/ ?>