
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    thead,tfoot{
        background-color:skyblue !important;
        color:black !important;
    }
    th{
        font-size:.7rem !important;
    }

    td{
        font-size:.7rem !important;
        font-weight:bold !important;
    }

    td .btn{
        font-size:.7rem !important;
    }
    </style>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h4 class="header-title" style="display:flex;align-items:center;justify-content:space-between;"><span> List of all Earnings By <?php echo e($agreegator->name); ?></span>
            <a href="<?php echo e(url("/agreegators")); ?>" class="btn btn-primary btn-sm">Agreegators</a>
        </h4>
           
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
               <?php endif; ?>

               <?php if(Session::get("error")): ?>
               <div class="alert alert-danger">
                <strong class="text-danger"><?php echo e(Session::get("error")); ?></strong>
               </div>
              <?php endif; ?>
               <?php if(count($earnings) == 0): ?>
               <strong class="text-danger">No Earnings yet</strong>
           
               <?php else: ?>

           <div class="table-responsive" id="deposits-content">
            <table  class="table table-striped dt-responsive nowrap w-100">
                <thead>
                    <tr>
                        <th></th>
                        <th>Agent Name</th>
                        <th>Transaction</th>
                        <th>Earning</th>
                        <th>Date</th>
                       
                    </tr>
                </thead>
            
            
                <tbody id="tbody">
                    <?php $__currentLoopData = $earnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $timestamp = strtotime($data->created_at) ;
                    $day = date("l",$timestamp);
                    $month = date("F",$timestamp);
                    $year = date("Y",$timestamp);
                    $time = date("h:i:A",$timestamp);
                    ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                       <td><?php echo e($data->name); ?></td>
                       <td><?php echo e($data->earned_from); ?></td>
                       <td>&#8358;<?php echo e($data->amount); ?></td>
                       <td><?php echo e($time); ?> <?php echo e($day); ?> <?php echo e($month); ?> <?php echo e(date("d",$timestamp)); ?> <?php echo e($year); ?></td>
                  
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
                <tfoot>
                    <tr>
                        <th></th>
                        <th>Agent Name</th>
                        <th>Transaction</th>
                        <th>Earning</th>
                        <th>Date</th>
                        
                        
                    </tr>
                </tfoot>
            </table>
            <br />
            
            <?php echo e($earnings->links()); ?>

   
        
           </div>
           <?php endif; ?>
   
       </div>
      </div>
   

   


<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/agreegator/agreegator_earnings.blade.php ENDPATH**/ ?>