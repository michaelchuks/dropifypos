
<?php $__env->startSection('content'); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                  
                                </div>
                                <h4 class="page-title">Wallet Balance For <?php echo e($user->name); ?> &#8358;<?php echo e($user->wallet); ?></h4>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                   
                                    <p class="text-muted font-14">
                                       Manage Agent Wallet Below
                                    </p>

                                  


                    <!-- Form row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Agent Wallet Balance &#8358;<?php echo e($user->wallet); ?></h4>
                                   

                                      <?php if(Session::get("success")): ?>
                                      <div class="alert alert-success">
                                        <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                                      </div>
                                      <?php endif; ?>

                                      <?php if(Session::get("error")): ?>
                                      <div class="alert alert-danger">
                                        <strong class="text-danger"><?php echo e(Session::get("error")); ?></strong>
                                      </div>
                                      <?php endif; ?>
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="form-row-preview">
                                            <form  method="post" action="<?php echo e(url("/manageagentwallet")); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="row g-2">
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputEmail4" class="form-label">Amount</label>
                                                        <input type="number" step="any" value="<?php echo e(old("amount")); ?>" name="amount" class="form-control" id="inputEmail4" >

                                                    </div>
                                                    <div class="mb-3 col-md-6">
                                                        <label for="inputPassword4" class="form-label">Select Transaction Type</label>
                                                      
                                                        <select  class="form-control" name="transaction_type">
                                                           
                                                            <option value="credit">Credit</option>
                                                            <option value="debit">debit</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                
                                                <input type="hidden" name="agent_id" value="<?php echo e($user->id); ?>" />

                                                <button  type="submit" name="wallet_agent_btn" class="btn btn-primary">Process Transaction</button>
                                            </form>
                                        </div> <!-- end preview-->

                                     
                                    </div> <!-- end tab-content-->

                                </div> <!-- end card-body -->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- container -->

            </div> <!-- content -->



<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/users/manage_wallet.blade.php ENDPATH**/ ?>