
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.adminavigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

      var data = google.visualization.arrayToDataTable([
        ['Transaction', 'Percentage'],
        ['VTU',     <?php echo $vtu; ?> ],
        ['Deposit',      <?php echo $deposit; ?>],
        ['Withdrawal',  <?php echo $withdrawal; ?>],
        ['Transfers', <?php echo $transfer; ?>],
       
      ]);

      var options = {
        title: 'Total Transactions'
      };

      var chart = new google.visualization.PieChart(document.getElementById('piechart'));

      chart.draw(data, options);
    }

    </script>

<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Dropifypay Pos Analytics for <?php echo e($data); ?></span> 
     <a class="btn btn-sm btn-danger"  href="<?php echo e(url("/redirect")); ?>">Back</a>
    </h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
              
            <div id="piechart" style="width: 100%; height: 100%;"></div>
          
       
   
       </div>
      </div>
   

     


<?php echo $__env->make("layouts.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.adminheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dropifypos\resources\views/analytics.blade.php ENDPATH**/ ?>