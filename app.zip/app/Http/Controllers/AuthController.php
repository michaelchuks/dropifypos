<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;
use App\Models\User;
use App\Models\Activities;
use App\Models\VtpassTransactions;
use App\Models\AdminEarnings;
use App\Models\States;

class AuthController extends Controller
{
     public function login(Request $request){
        if($request->has("admin_login_btn")){
            $request->validate([
                "email" => "required|email",
                "password" => "required"
            ]);

            $admin = Admin::where("email","=",$request->email)->where('role',"=",'admin')->first();
            if($admin){
                if(Hash::check($request->password,$admin->password)){
                    session()->put("loggedAdmin",$admin->id);
                    return redirect()->to("/dashboard");
                }else{
                    return redirect()->back()->with('error',"invalid admin password");
                }
            }else{
                return redirect()->back()->with("error","invalid admin email");
            }
        }else{
            return redirect()->to("/");
        }
     }




     public function createAdmin(){
        $admin = new Admin();
        $admin->email = "dropifyadmin@gmail.com";
        $admin->password = Hash::make("admin123");
        $admin->role = 'admin';
        $admin->save();
        echo "done";
     }



     public function dashboard(){

      
        $total_users = User::where("status","!=","registered")->count();
        $total_transactions = Activities::count();
        $admin_earnings = AdminEarnings::sum("amount");
        $users_transactions = Activities::sum("amount");

        return view("dashboard")->with("total_users",$total_users)
        ->with("total_transactions",$total_transactions)
        ->with("admin_earnings",$admin_earnings)
        ->with("users_transactions",$users_transactions);
    }


    
    public function account(){
        $admin = Admin::find(session()->get("loggedAdmin"));
        return view("account")->with("admin",$admin);
    }
  
  
  
    Public function resetAccount(Request $request){
        if($request->has("reset_account_btn")){
            if(!$request->filled("email") && !$request->filled("password")){
              return redirect()->back()->with("error","You did not fill and field to update");
            }else{
              $id = $request->admin_id;
  
              if($request->filled('email')){
                Admin::find($id)->update([
                  "email" => $request->email
                ]);
  
              }
  
              if($request->filled("password")){
                Admin::find($id)->update([
                  "password" => Hash::make($request->password)
                ]);
  
              }
  
              return redirect()->back()->with("success","Admin details updated successfully");
            }
        }else{
            return redirect()->to('/admin');
        }
    }
  




    public function logout(){
        session()->pull("loggedAdmin");
        return redirect()->to("/");
    }




    public function register(){
      $states = States::get();
      return  view("register.register")->with("states",$states);
    }
}
